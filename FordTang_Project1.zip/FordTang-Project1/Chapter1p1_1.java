/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter1p1_1;

/**
 *
 * @author C02122472
 */
public class Chapter1p1_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("+----+");
        System.out.println("|Ford|");
        System.out.println("+----+");
    }
}
