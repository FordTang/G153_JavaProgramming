/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Chapter1p1_8;

/**
 *
 * @author C02122472
 */
public class Chapter1p1_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //int sum10 = 1+2+3+4+5+6+7+8+9+10;
        System.out.println("The sum of the first ten positive integers is: ");
        System.out.print("1+2+3+4+5+6+7+8+9+10 = ");
        System.out.println(1+2+3+4+5+6+7+8+9+10);
        //System.out.println(sum10);
    }
}
